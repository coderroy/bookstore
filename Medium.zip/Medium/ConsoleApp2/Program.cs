﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleApp2
{
    class City 
    {
        long cityId;
        string cityName;
        string state;

        public long CityId { get => cityId; set => cityId = value; }
        public string CityName { get => cityName; set => cityName = value; }
        public string State { get => state; set => state = value; }
    }
    class Review
    {
        long reviewId;
        string createdDate;
        byte isActive;
        byte isReportAbused;
        public string reviewText;
        public string reviewer;

        public Review(long reviewId, string createdDate, byte isActive, byte isReportAbused, string reviewText, string reviewer)
        {
            this.reviewId = reviewId;
            this.createdDate = createdDate;
            this.isActive = isActive;
            this.isReportAbused = isReportAbused;
            this.reviewText = reviewText;
            this.reviewer = reviewer;
        }

        public long ReviewId { get => reviewId; set => reviewId = value; }
        public string CreatedDate { get => createdDate; set => createdDate = value; }
        public byte IsActive { get => isActive; set => isActive = value; }
        public byte IsReportAbused { get => isReportAbused; set => isReportAbused = value; }
        public string ReviewText { get => reviewText; set => reviewText = value; }
        public string Reviewer { get => reviewer; set => reviewer = value; }
    }
    class Hotel : City
    {
        long hotelId;
        string breifNote;
        string hotelName;
        string photoUrl;
        int starRating;
        public ArrayList reviews;
        public Hotel() {; }
        public Hotel(long hotelId, string breifNote, string hotelName, string photoUrl, int starRating, ArrayList reviews)
        {
            this.hotelId = hotelId;
            this.breifNote = breifNote;
            this.hotelName = hotelName;
            this.photoUrl = photoUrl;
            this.starRating = starRating;
            this.reviews = reviews;
        }

        public long HotelId { get => hotelId; set => hotelId = value; }
        public string BreifNote { get => breifNote; set => breifNote = value; }
        public string HotelName { get => hotelName; set => hotelName = value; }
        public string PhotoUrl { get => photoUrl; set => photoUrl = value; }
        public int StarRating { get => starRating; set => starRating = value; }
        //public ArrayList Reviews { get => reviews; set => reviews = value; }
    }
    
    class HotelManager
    {
        //public Hotel hotel_addr;
        public void createHotel(ref Hotel hotel)
        {
            Review rev = new Review(1, ("12-04-2018"), 1, 0, "Excellent", "Sewanand");
            ArrayList list = new ArrayList();
            list.Add(rev);
            rev = new Review(2, "12-04-2012", 1, 0, "poor", "Atul");
            list.Add(rev);
            hotel = new Hotel(1, "fdsf", "Ginger Hotel", "kdjs", 5, list);
            
        }
        public void showHotelDetails(Hotel hotel)
        {
            if(hotel == null)
            {
                Console.WriteLine("NUll value");
                return;
            }
            Console.WriteLine(hotel.HotelName);
        }
        public void showReviewsforHotels(Hotel hotel)
        {
            foreach (Review item in hotel.reviews)
            {
                
                Console.WriteLine(item.Reviewer+" "+item.ReviewText);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            HotelManager mgr = new HotelManager();
            Hotel hotel = new Hotel();
            mgr.createHotel(ref hotel);
            mgr.showHotelDetails(hotel);
            mgr.showReviewsforHotels(hotel);
        }
    }
}
