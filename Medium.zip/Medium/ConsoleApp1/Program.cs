﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Room
    {
        int roomNo;
        int floorNo;
        double cost;

        public int RoomNo { get => roomNo; set => roomNo = value; }
        public int FloorNo { get => floorNo; set => floorNo = value; }
        public double Cost { get => cost; set => cost = value; }
    }
    class ConferenceRoom : Room
    {
        int noOfChairs;
        bool extraBedAllowed;
        string roomType;

        public int NoOfChairs { get => noOfChairs; set => noOfChairs = value; }
        public bool ExtraBedAllowed { get => extraBedAllowed; set => extraBedAllowed = value; }
        public string RoomType { get => roomType; set => roomType = value; }
    }
    class GuestRoom : Room
    {
        int noOfBeds;
        bool extraBedAllowed;
        string roomType;

        public int NoOfBeds { get => noOfBeds; set => noOfBeds = value; }
        public bool ExtraBedAllowed { get => extraBedAllowed; set => extraBedAllowed = value; }
        public string RoomType { get => roomType; set => roomType = value; }
    }
    class RoomBookingManager
    {
        public void BookRoom (Room room)
        {
            if (room is ConferenceRoom)
            {
                ConferenceRoom conf = (ConferenceRoom)room;
                Console.WriteLine("Enter room no.");
                conf.RoomNo = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter floor no.");
                conf.FloorNo = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter floor no.");
                conf.FloorNo = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter cost");
                conf.Cost = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter number of chairs");
                conf.NoOfChairs = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter if extra bed is allowed");
                if (int.Parse(Console.ReadLine()) == 0)
                    conf.ExtraBedAllowed = false;
                else
                    conf.ExtraBedAllowed = true;
                Console.WriteLine("Enter room type");
                conf.RoomType = (Console.ReadLine());
            }
            else if(room is GuestRoom)
            {
                GuestRoom guest = (GuestRoom)room;
                Console.WriteLine("Enter room no.");
                guest.RoomNo = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter floor no.");
                guest.FloorNo = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter floor no.");
                guest.FloorNo = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter cost");
                guest.Cost = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter number of chairs");
                guest.NoOfBeds = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter if extra bed is allowed");
                if (int.Parse(Console.ReadLine()) == 0)
                    guest.ExtraBedAllowed = false;
                else
                    guest.ExtraBedAllowed = true;
                Console.WriteLine("Enter room type");
                guest.RoomType = (Console.ReadLine());
            }
        }
        public void ShowRoomDetails(Room room)
        {
            if (room is ConferenceRoom)
            {
                ConferenceRoom conf = (ConferenceRoom)room;
                Console.WriteLine("Room Details: \n{0} {1} {2} {3} {4} {5}",
                    conf.RoomNo,conf.FloorNo,conf.Cost,conf.NoOfChairs,conf.ExtraBedAllowed,conf.RoomType);
            }
            else if (room is GuestRoom)
            {
                GuestRoom guest = (GuestRoom)room;
                Console.WriteLine("Room Details: \n{0} {1} {2} {3} {4} {5}",
                    guest.RoomNo, guest.FloorNo, guest.Cost, guest.NoOfBeds, guest.ExtraBedAllowed, guest.RoomType);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Room guest = new GuestRoom();
            Room Conf = new ConferenceRoom();
            RoomBookingManager mgr = new RoomBookingManager();
            mgr.BookRoom(guest);
            mgr.ShowRoomDetails(guest);
            mgr.BookRoom(Conf);
            mgr.ShowRoomDetails(Conf);
            
        }
    }
}
